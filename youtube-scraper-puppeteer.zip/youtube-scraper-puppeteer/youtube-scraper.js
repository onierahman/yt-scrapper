const puppeteer = require('puppeteer');
const readline = require('readline-sync');
const fs = require('fs');

async function scrapeVideoData(url) {
    // Puppeteer scraping logic here

    const browser = await puppeteer.launch({ headless: 'new' });
    const page = await browser.newPage();
    await page.goto(url);

    // Wait for relevant elements to load
    await page.waitForSelector('#info-contents');

    const videoTitle = await page.$eval('.title.style-scope.ytd-video-primary-info-renderer', element => element.textContent.trim());
    const viewsCount = await page.$eval('.view-count.style-scope.ytd-video-view-count-renderer', element => element.textContent.trim());
    
    let likes = 0;
    let dislikes = 0;
    
   // const likeButton = await page.$('.yt-spec-button-shape-next__button-text-content');
   const likeButton = await page.$eval('#segmented-like-button > ytd-toggle-button-renderer > yt-button-shape > button > div.cbox.yt-spec-button-shape-next__button-text-content > span', element => element.textContent.trim());


   if (likeButton) {
    // likes = await likeButton.evaluate(element => element.textContent.trim());
    likes = likeButton;
}

 

    await browser.close();

    return {
        title: videoTitle,
        views: viewsCount,
        likes: likes,
    };
}

async function searchVideos(query) {
    // Puppeteer search logic here

    const browser = await puppeteer.launch({ headless: 'new' });
    const page = await browser.newPage();
    await page.goto(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);

    await page.waitForSelector('ytd-video-renderer #video-title', { visible: true });

    const videoElements = await page.$$('ytd-video-renderer');
    const searchResults = [];

    for (const videoElement of videoElements) {
                const title = await videoElement.$eval('#video-title', element => element.textContent.trim());
                // Get the URL from the anchor tag's href attribute
                const urlElement = await videoElement.$('#thumbnail');
                const url = await (await urlElement.getProperty('href')).jsonValue();
                // Extract the views count text and convert it to a number
                const viewsElement = await videoElement.$('ytd-video-meta-block');
                const viewsText = viewsElement ? await (await viewsElement.getProperty('textContent')).jsonValue() : 'Views not available';
                const views = viewsText !== 'Views not available' ? parseInt(viewsText.replace(/[^0-9]/g, '')) : 0;

                //upload time 

                


        searchResults.push({ title, url, views });
    }

    await browser.close();

    return searchResults;

}

function calculateAverage(array) {
    // Calculate average value of an array
    const sum = array.reduce((total, value) => total + value, 0);
    return sum / array.length;

}

async function main() {
    console.log('Welcome to YouTube Video Scraper and Analyzer');

    while (true) {
        console.log('1. Search for videos');
        console.log('2. Quit');

        const choice = readline.question('Enter your choice: ');

        if (choice === '1') {
            const query = readline.question('Enter search query: ');
            const searchResults = await searchVideos(query);

            console.log('Search Results:');
            searchResults.forEach((video, index) => {
                console.log(`${index + 1}. Title: ${video.title} \n URL: ${video.url} \n views:  ${video.views}  `);
            });

            const selectedVideoIndex = parseInt(readline.question('Enter the number of the video to get details: '));

            if (selectedVideoIndex >= 1 && selectedVideoIndex <= searchResults.length) {
                const selectedVideo = searchResults[selectedVideoIndex - 1];
                const videoData = await scrapeVideoData(selectedVideo.url);

                // Display video details
                console.log('Video Details:');
                console.log(`Title: ${videoData.title}`);
                console.log(`Views: ${videoData.views}`);
                console.log(`Likes: ${videoData.likes}`);
                console.log(`Upload Date: ${videoData.uploadDate}`);

                // Calculate analysis
                const viewsArray = searchResults.map(video => parseInt(video.views));
                const likesArray = searchResults.map(video => parseInt(video.likes));
                const averageViews = calculateAverage(viewsArray);
                const averageLikes = calculateAverage(likesArray);

                console.log('Analysis Results:');
                console.log(`Average Views: ${averageViews}`);
                console.log(`Average Likes: ${averageLikes}`);

                // Export data to CSV or JSON
                const exportChoice = readline.question('Export video data to CSV (c) or JSON (j)? ');
                if (exportChoice.toLowerCase() === 'c') {
                    // Export to CSV
                    const csvData = searchResults.map(video => `${video.title},${video.url},${video.views}`).join('\n');
                    fs.writeFileSync('videos.csv', 'Title,URL,Views\n' + csvData, 'utf-8');
                    console.log('Data exported to videos.csv');

                } else if (exportChoice.toLowerCase() === 'j') {
                    // Export to JSON
                    const jsonData = JSON.stringify(searchResults, null, 2);
                    fs.writeFileSync('videos.json', jsonData, 'utf-8');
                    console.log('Data exported to videos.json');

                }
            } else {
                console.log('Invalid video selection.');
            }
        } else if (choice === '2') {
            console.log('Goodbye!');
            break;
        } else {
            console.log('Invalid choice. Please select a valid option.');
        }
    }
}

main();
